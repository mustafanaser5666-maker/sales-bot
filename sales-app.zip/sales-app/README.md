# تطبيق المبيعات 🛍️

تطبيق بسيط لاستقبال طلبات الزبائن وإرسالها مباشرة عبر تلغرام.

## تشغيل محلي

```bash
npm install
npm run dev
```

## النشر على Vercel

1. ارفع المشروع على GitHub
2. اذهب إلى [vercel.com](https://vercel.com)
3. اضغط **New Project** واختر الـ repo
4. اضغط **Deploy** — خلاص! ✅
