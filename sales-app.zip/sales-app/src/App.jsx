import { useState } from "react";
import "./App.css";

const BOT_TOKEN = "8983511233:AAEmCYNs-llyl12YVHRjdJ_o0u20-cMYQCk";
const CHAT_ID = "1312627565";

function Field({ label, error, children }) {
  return (
    <div className="field">
      <label>{label}</label>
      {children}
      {error && <span className="err">{error}</span>}
    </div>
  );
}

function Row({ label, val, last }) {
  return (
    <div className={`info-row ${last ? "last" : ""}`}>
      <span className="info-label">{label}</span>
      <span className="info-val">{val}</span>
    </div>
  );
}

export default function App() {
  const [form, setForm] = useState({ name: "", phone: "", address: "" });
  const [errors, setErrors] = useState({});
  const [step, setStep] = useState("form");

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "يرجى إدخال الاسم";
    if (!/^[0-9]{10,15}$/.test(form.phone.replace(/\s/g, "")))
      e.phone = "رقم هاتف غير صحيح";
    if (form.address.trim().length < 5) e.address = "يرجى إدخال العنوان";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    setStep("loading");

    const now = new Date().toLocaleString("ar-SA", { timeZone: "Asia/Riyadh" });
    const msg =
      `🛒 *طلب جديد*\n` +
      `━━━━━━━━━━━━━━\n` +
      `👤 *الاسم:* ${form.name}\n` +
      `📞 *الهاتف:* ${form.phone}\n` +
      `📍 *العنوان:* ${form.address}\n` +
      `━━━━━━━━━━━━━━\n` +
      `🕐 ${now}`;

    try {
      const res = await fetch(
        `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            chat_id: CHAT_ID,
            text: msg,
            parse_mode: "Markdown",
          }),
        }
      );
      const data = await res.json();
      if (data.ok) setStep("success");
      else setStep("error");
    } catch {
      setStep("error");
    }
  };

  const restart = () => {
    setForm({ name: "", phone: "", address: "" });
    setErrors({});
    setStep("form");
  };

  if (step === "loading")
    return (
      <div className="root" dir="rtl">
        <div className="card">
          <div className="spinner" />
          <p className="load-txt">جاري إرسال الطلب...</p>
        </div>
      </div>
    );

  if (step === "success")
    return (
      <div className="root" dir="rtl">
        <div className="card">
          <div className="ok-icon">✓</div>
          <h2 className="ok-title">تم تأكيد الطلب!</h2>
          <p className="sub">تم إرسال طلبك عبر تلغرام ✈️</p>
          <div className="info-box">
            <Row label="الاسم" val={form.name} />
            <Row label="الهاتف" val={form.phone} />
            <Row label="العنوان" val={form.address} last />
          </div>
          <button className="btn" onClick={restart}>
            طلب جديد 🛍️
          </button>
        </div>
      </div>
    );

  if (step === "error")
    return (
      <div className="root" dir="rtl">
        <div className="card">
          <div className="err-icon">!</div>
          <h2 className="err-title">حدث خطأ</h2>
          <p className="sub">لم يتم إرسال الطلب، حاول مجدداً</p>
          <button className="btn" onClick={restart}>
            حاول مجدداً
          </button>
        </div>
      </div>
    );

  return (
    <div className="root" dir="rtl">
      <div className="card">
        <div className="logo">🛍️</div>
        <h1 className="title">تأكيد الطلب</h1>
        <p className="sub">أدخل بياناتك وسنتواصل معك قريباً</p>

        <Field label="الاسم الكامل" error={errors.name}>
          <input
            className={`input ${errors.name ? "input-err" : ""}`}
            placeholder="محمد أحمد"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
        </Field>

        <Field label="رقم الهاتف" error={errors.phone}>
          <input
            className={`input ${errors.phone ? "input-err" : ""}`}
            placeholder="05xxxxxxxx"
            value={form.phone}
            type="tel"
            inputMode="numeric"
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
          />
        </Field>

        <Field label="العنوان" error={errors.address}>
          <textarea
            className={`textarea ${errors.address ? "input-err" : ""}`}
            placeholder="المدينة، الحي، الشارع..."
            rows={3}
            value={form.address}
            onChange={(e) => setForm({ ...form, address: e.target.value })}
          />
        </Field>

        <button className="btn" onClick={handleSubmit}>
          تأكيد الطلب ✓
        </button>
        <p className="foot">📨 سيصلك تأكيد عبر تلغرام</p>
      </div>
    </div>
  );
}
